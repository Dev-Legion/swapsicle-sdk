import { JSBI } from '..'

export interface Rebase {
  base: JSBI
  elastic: JSBI
}
