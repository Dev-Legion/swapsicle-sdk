export enum TradeType {
  EXACT_INPUT,
  EXACT_OUTPUT,
}
