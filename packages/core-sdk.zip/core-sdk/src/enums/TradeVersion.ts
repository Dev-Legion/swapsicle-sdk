export enum TradeVersion {
  V2TRADE,
  V3TRADE,
}
