export enum SolidityType {
    uint8 = 'uint8',
    uint256 = 'uint256',
}