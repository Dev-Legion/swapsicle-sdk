export type AddressMap = { [chainId: number]: string }
