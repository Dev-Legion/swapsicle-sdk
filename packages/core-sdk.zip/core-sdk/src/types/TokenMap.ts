import { Token } from '../entities'

export type TokenMap = { [chainId: number]: Token }
