import { NativeCurrency } from '../entities'

export type NativeMap = { [chainId: number]: NativeCurrency }
